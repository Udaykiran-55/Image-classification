# 🧠 Image Classifier - PyTorch + Django

AI-powered image classification web app using **Transfer Learning (ResNet18)** with confidence scores for every prediction.

---

## 📁 Project Structure

```
image_classifier/
├── manage.py
├── requirements.txt
├── train_model.py          ← Run this FIRST to train the model
├── image_classifier/       ← Django project settings
│   ├── settings.py
│   └── urls.py
├── classifier/             ← Django app
│   ├── models.py
│   ├── views.py
│   ├── predictor.py        ← PyTorch inference logic
│   ├── urls.py
│   └── templates/classifier/
│       ├── index.html      ← Upload & classify page
│       └── history.html    ← Prediction history page
├── model/                  ← Trained model saved here
│   ├── image_classifier.pth
│   └── class_names.txt
├── media/uploads/          ← Uploaded images stored here
└── dataset/                ← YOUR DATASET GOES HERE (see below)
    ├── train/
    │   ├── class1/
    │   └── class2/
    └── val/
        ├── class1/
        └── class2/
```

---

## 🚀 Setup & Run (Step by Step)

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Prepare Your Dataset

Organize your Kaggle dataset like this:
```
dataset/
    train/
        synthetic/          ← Synthetic (Kakuda) images for training
            img001.jpg
            img002.jpg
        real/               ← Real (Kavali) images for training
            img001.jpg
    val/
        synthetic/          ← 20% of synthetic for validation
        real/               ← 20% of real for validation
```

> **Note:** Folder names become class labels automatically!
> You can have any number of classes (cat/dog, disease/healthy, etc.)

### Step 3: Train the Model
```bash
python train_model.py
```
- This will train ResNet18 with transfer learning
- Best model saved to `model/image_classifier.pth`
- Takes 5–30 mins depending on dataset size and GPU availability

### Step 4: Run Django Server
```bash
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

### Step 5: Open Browser
```
http://127.0.0.1:8000/
```

---

## 🌐 Web App Features

| Feature | Description |
|---|---|
| 📤 Image Upload | Upload JPG/PNG/WEBP images |
| 🎯 Confidence Score | Shows prediction confidence % |
| 📊 All Class Probabilities | Bar chart for all classes |
| 🕒 Prediction History | All past predictions stored |
| 🖼️ Image Preview | Preview before classifying |

---

## 🧪 How the AI Works

1. **Model**: ResNet18 (pretrained on ImageNet)
2. **Transfer Learning**: Frozen feature layers + custom classification head
3. **Output**: Softmax probabilities for each class → confidence %
4. **Training**: Adam optimizer + StepLR scheduler

---

## 💡 Tips for Your Dataset (Kakuda + Kavali)

- Minimum 100 images per class recommended
- More data = better accuracy
- Use data augmentation (already enabled in `train_model.py`)
- Aim for balanced classes (equal images per class)

---

## 📊 Expected Results

| Dataset Size | Expected Accuracy |
|---|---|
| 100–500 images/class | 75–85% |
| 500–2000 images/class | 85–92% |
| 2000+ images/class | 90–96% |
