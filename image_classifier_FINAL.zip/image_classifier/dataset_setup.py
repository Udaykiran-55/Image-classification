"""
dataset_setup.py - Automatic Dataset Download & Setup Script
============================================================
Run this script to automatically download and organize your dataset.

USAGE:
    python dataset_setup.py

OPTIONS:
    1. Download from Kaggle (Animals / Flowers / Disease datasets)
    2. Generate Synthetic dataset (no internet needed)
    3. Use your own images
"""

import os
import sys
import shutil
import random
from pathlib import Path

# ===================== CONFIG =====================
DATASET_DIR = "dataset"
TRAIN_RATIO = 0.8   # 80% train, 20% val
# ==================================================


def print_banner():
    print("=" * 55)
    print("   IMAGE CLASSIFIER - Dataset Setup Tool")
    print("=" * 55)


def create_folder_structure(classes):
    """Create train/val folders for each class."""
    for split in ['train', 'val']:
        for cls in classes:
            os.makedirs(os.path.join(DATASET_DIR, split, cls), exist_ok=True)
    print(f"✅ Folder structure created for classes: {classes}")


def split_images(source_dir, class_name):
    """Split images from source into train/val."""
    images = [f for f in os.listdir(source_dir)
              if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp', '.bmp'))]
    random.shuffle(images)

    split_idx = int(len(images) * TRAIN_RATIO)
    train_imgs = images[:split_idx]
    val_imgs = images[split_idx:]

    for img in train_imgs:
        shutil.copy(
            os.path.join(source_dir, img),
            os.path.join(DATASET_DIR, 'train', class_name, img)
        )
    for img in val_imgs:
        shutil.copy(
            os.path.join(source_dir, img),
            os.path.join(DATASET_DIR, 'val', class_name, img)
        )

    print(f"  {class_name}: {len(train_imgs)} train, {len(val_imgs)} val")


# ─────────────────────────────────────────────────
# OPTION 1: Download from Kaggle
# ─────────────────────────────────────────────────
def download_from_kaggle():
    print("\n📦 Kaggle Dataset Download")
    print("-" * 40)
    print("Available datasets:")
    print("  1. Animals (Cat/Dog) - microsoft/cats-and-dogs")
    print("  2. Flowers           - alxmamaev/flowers-recognition")
    print("  3. Brain Tumor MRI   - navoneel/brain-mri-images-for-brain-tumor-detection")
    print("  4. Custom (enter your own Kaggle dataset)")

    choice = input("\nEnter choice (1-4): ").strip()

    datasets = {
        "1": {
            "name": "microsoft/catsvsdogs",
            "classes": {"Cat": "PetImages/Cat", "Dog": "PetImages/Dog"}
        },
        "2": {
            "name": "alxmamaev/flowers-recognition",
            "classes": {
                "daisy": "flowers/daisy",
                "dandelion": "flowers/dandelion",
                "rose": "flowers/rose",
                "sunflower": "flowers/sunflower",
                "tulip": "flowers/tulip"
            }
        },
        "3": {
            "name": "navoneel/brain-mri-images-for-brain-tumor-detection",
            "classes": {"yes": "yes", "no": "no"}
        },
    }

    if choice == "4":
        dataset_name = input("Enter Kaggle dataset (e.g., username/dataset-name): ").strip()
        print("\n⚠️  For custom datasets, organize manually after download.")
        kaggle_dataset = dataset_name
        classes_map = None
    elif choice in datasets:
        kaggle_dataset = datasets[choice]["name"]
        classes_map = datasets[choice]["classes"]
    else:
        print("Invalid choice!")
        return

    # Check kaggle API is installed
    try:
        import kaggle
    except ImportError:
        print("\n❌ Kaggle package not installed.")
        print("Run: pip install kaggle")
        print("\nAlso setup your Kaggle API key:")
        print("  1. Go to https://www.kaggle.com/account")
        print("  2. Click 'Create New API Token' → downloads kaggle.json")
        print("  3. Place kaggle.json in: ~/.kaggle/kaggle.json")
        return

    print(f"\n⬇️  Downloading: {kaggle_dataset}")
    download_path = "kaggle_downloads"
    os.makedirs(download_path, exist_ok=True)

    os.system(f"kaggle datasets download -d {kaggle_dataset} -p {download_path} --unzip")

    if classes_map:
        print("\n📂 Organizing dataset...")
        create_folder_structure(list(classes_map.keys()))
        for class_name, relative_path in classes_map.items():
            source = os.path.join(download_path, relative_path)
            if os.path.exists(source):
                split_images(source, class_name)
            else:
                print(f"  ⚠️ Path not found: {source} — check manually")
        print("\n✅ Dataset ready!")
        print_summary()
    else:
        print(f"\n📁 Raw files downloaded to: {download_path}/")
        print("Please organize them manually as shown in README.md")


# ─────────────────────────────────────────────────
# OPTION 2: Generate Synthetic Dataset
# ─────────────────────────────────────────────────
def generate_synthetic_dataset():
    print("\n🎨 Generating Synthetic Dataset (for testing)")
    print("-" * 40)

    try:
        from PIL import Image, ImageDraw
        import numpy as np
    except ImportError:
        print("Run: pip install Pillow numpy")
        return

    classes = {
        "synthetic": {
            "color": (100, 149, 237),    # Cornflower blue (Kakuda)
            "shape": "circle"
        },
        "real": {
            "color": (144, 238, 144),    # Light green (Kavali)
            "shape": "rectangle"
        }
    }

    images_per_class = 200   # Total images per class

    print(f"Creating {images_per_class} images per class...")
    create_folder_structure(list(classes.keys()))

    for class_name, props in classes.items():
        all_images = []

        for i in range(images_per_class):
            img = Image.new('RGB', (224, 224), color=(240, 240, 240))
            draw = ImageDraw.Draw(img)

            # Random noise background
            for _ in range(500):
                x, y = random.randint(0, 223), random.randint(0, 223)
                r, g, b = [max(0, min(255, c + random.randint(-30, 30)))
                           for c in props["color"]]
                draw.point((x, y), fill=(r, g, b, 50))

            # Main shape
            color = tuple(max(0, min(255, c + random.randint(-40, 40)))
                         for c in props["color"])
            x1 = random.randint(30, 80)
            y1 = random.randint(30, 80)
            x2 = random.randint(140, 200)
            y2 = random.randint(140, 200)

            if props["shape"] == "circle":
                draw.ellipse([x1, y1, x2, y2], fill=color, outline=(50,50,50), width=3)
            else:
                draw.rectangle([x1, y1, x2, y2], fill=color, outline=(50,50,50), width=3)

            all_images.append(img)

        # Split train/val
        split_idx = int(images_per_class * TRAIN_RATIO)
        for idx, img in enumerate(all_images[:split_idx]):
            img.save(os.path.join(DATASET_DIR, 'train', class_name, f"{class_name}_{idx:04d}.jpg"))
        for idx, img in enumerate(all_images[split_idx:]):
            img.save(os.path.join(DATASET_DIR, 'val', class_name, f"{class_name}_{idx:04d}.jpg"))

        print(f"  ✅ {class_name}: {split_idx} train, {images_per_class - split_idx} val")

    print("\n✅ Synthetic dataset ready!")
    print("💡 Classes: 'synthetic' (circles/blue) vs 'real' (rectangles/green)")
    print_summary()


# ─────────────────────────────────────────────────
# OPTION 3: Use your own images
# ─────────────────────────────────────────────────
def use_own_images():
    print("\n📁 Use Your Own Images")
    print("-" * 40)
    print("Place your images in the following structure:")
    print()
    print("  my_images/")
    print("    synthetic/       ← All your Kakuda/synthetic images")
    print("    real/            ← All your Kavali/real images")
    print()

    source_dir = input("Enter path to your images folder (default: my_images): ").strip()
    if not source_dir:
        source_dir = "my_images"

    if not os.path.exists(source_dir):
        print(f"\n❌ Folder '{source_dir}' not found!")
        print(f"Please create it and add your images.")
        return

    classes = [d for d in os.listdir(source_dir)
               if os.path.isdir(os.path.join(source_dir, d))]

    if not classes:
        print("❌ No class folders found inside the directory!")
        return

    print(f"\nFound classes: {classes}")
    create_folder_structure(classes)

    for cls in classes:
        src = os.path.join(source_dir, cls)
        split_images(src, cls)

    print("\n✅ Dataset organized!")
    print_summary()


def print_summary():
    print("\n" + "=" * 45)
    print("📊 DATASET SUMMARY")
    print("=" * 45)
    for split in ['train', 'val']:
        split_path = os.path.join(DATASET_DIR, split)
        if os.path.exists(split_path):
            print(f"\n  [{split.upper()}]")
            total = 0
            for cls in sorted(os.listdir(split_path)):
                cls_path = os.path.join(split_path, cls)
                if os.path.isdir(cls_path):
                    count = len([f for f in os.listdir(cls_path)
                                 if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))])
                    print(f"    {cls}: {count} images")
                    total += count
            print(f"    TOTAL: {total} images")
    print("\n✅ Now run: python train_model.py")
    print("=" * 45)


# ─────────────────────────────────────────────────
# MAIN MENU
# ─────────────────────────────────────────────────
def main():
    print_banner()
    print("\nHow do you want to get your dataset?\n")
    print("  1. Download from Kaggle (Cats/Dogs/Flowers/Disease/Custom)")
    print("  2. Generate Synthetic dataset (no internet needed, for testing)")
    print("  3. Use my own images (already downloaded)")
    print("  4. Exit")

    choice = input("\nEnter your choice (1-4): ").strip()

    if choice == "1":
        download_from_kaggle()
    elif choice == "2":
        generate_synthetic_dataset()
    elif choice == "3":
        use_own_images()
    elif choice == "4":
        print("Bye!")
        sys.exit(0)
    else:
        print("Invalid choice! Please enter 1, 2, 3, or 4.")


if __name__ == '__main__':
    main()
