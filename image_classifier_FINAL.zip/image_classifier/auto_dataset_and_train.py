"""
auto_dataset_and_train.py
==========================
ONE SCRIPT TO RULE ALL:
 - Kaggle large real dataset download (Cats vs Dogs - 25,000 images)
 - Synthetic dataset generate (Kakuda style)
 - Both combine chesi train/val split
 - Model train chesi save cheyyandi

RUN:
    python auto_dataset_and_train.py
"""

import os
import sys
import shutil
import random
from pathlib import Path

print("=" * 60)
print("   AUTO DATASET + TRAIN SCRIPT")
print("   Synthetic (Kakuda) + Real (Kaggle) Combined")
print("=" * 60)

# ─────────────────────────────────────────────
# STEP 1: Install packages if missing
# ─────────────────────────────────────────────
def install_if_missing(pkg, import_name=None):
    import_name = import_name or pkg
    try:
        __import__(import_name)
    except ImportError:
        print(f"Installing {pkg}...")
        os.system(f"{sys.executable} -m pip install {pkg} -q")

install_if_missing("kaggle")
install_if_missing("Pillow", "PIL")
install_if_missing("torch")
install_if_missing("torchvision")
install_if_missing("numpy")

# ─────────────────────────────────────────────
# STEP 2: Generate Synthetic Dataset (Kakuda)
# ─────────────────────────────────────────────
def generate_synthetic(output_dir, num_images=500):
    from PIL import Image, ImageDraw, ImageFilter
    import numpy as np

    print(f"\n[1/3] Generating {num_images} Synthetic (Kakuda) images...")
    os.makedirs(os.path.join(output_dir, "train", "synthetic"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "val",   "synthetic"), exist_ok=True)

    all_imgs = []
    shapes   = ["circle", "rectangle", "triangle", "star"]
    palettes = [
        (100, 149, 237), (255, 165, 0), (220, 20, 60),
        (50, 205, 50),   (147, 112, 219), (255, 215, 0)
    ]

    for i in range(num_images):
        img  = Image.new("RGB", (224, 224), color=(230 + random.randint(-20, 20),) * 3)
        draw = ImageDraw.Draw(img)

        # Random noisy background
        for _ in range(800):
            x, y = random.randint(0, 223), random.randint(0, 223)
            c = random.randint(180, 255)
            draw.point((x, y), fill=(c, c, c))

        # Main shape
        color = random.choice(palettes)
        color = tuple(max(0, min(255, c + random.randint(-30, 30))) for c in color)
        shape = random.choice(shapes)
        x1, y1 = random.randint(20, 70),  random.randint(20, 70)
        x2, y2 = random.randint(150, 200), random.randint(150, 200)

        if shape == "circle":
            draw.ellipse([x1, y1, x2, y2], fill=color, outline=(30, 30, 30), width=3)
        elif shape == "rectangle":
            draw.rectangle([x1, y1, x2, y2], fill=color, outline=(30, 30, 30), width=3)
        elif shape == "triangle":
            draw.polygon([(x1, y2), (x2, y2), ((x1+x2)//2, y1)], fill=color, outline=(30, 30, 30))
        else:  # star approximate
            cx, cy = (x1+x2)//2, (y1+y2)//2
            r = min(x2-x1, y2-y1) // 2
            pts = []
            import math
            for k in range(5):
                angle = math.radians(k * 72 - 90)
                pts.append((cx + r*math.cos(angle), cy + r*math.sin(angle)))
                angle2 = math.radians(k*72 + 36 - 90)
                pts.append((cx + r//2*math.cos(angle2), cy + r//2*math.sin(angle2)))
            draw.polygon(pts, fill=color, outline=(30, 30, 30))

        img = img.filter(ImageFilter.GaussianBlur(radius=random.uniform(0, 0.8)))
        all_imgs.append(img)

    split = int(num_images * 0.8)
    for idx, im in enumerate(all_imgs[:split]):
        im.save(os.path.join(output_dir, "train", "synthetic", f"synth_{idx:05d}.jpg"))
    for idx, im in enumerate(all_imgs[split:]):
        im.save(os.path.join(output_dir, "val", "synthetic", f"synth_{idx:05d}.jpg"))

    print(f"   ✅ Synthetic: {split} train, {num_images - split} val")


# ─────────────────────────────────────────────
# STEP 3: Download Real Dataset from Kaggle
# ─────────────────────────────────────────────
def download_real_dataset(output_dir):
    print("\n[2/3] Downloading Real Dataset from Kaggle...")
    print("      Dataset: microsoft/catsvsdogs (25,000 images)")
    print()

    # Check kaggle.json
    kaggle_json = os.path.expanduser("~/.kaggle/kaggle.json")
    if not os.path.exists(kaggle_json):
        print("─" * 55)
        print("❌ kaggle.json NOT FOUND!")
        print()
        print("To get it:")
        print("  1. Go to: https://www.kaggle.com/settings")
        print("  2. Scroll to 'API' section")
        print("  3. Click 'Create New API Token'")
        print("     → Downloads kaggle.json")
        print()
        print("  Windows: Copy to C:\\Users\\YourName\\.kaggle\\kaggle.json")
        print("  Linux  : Copy to ~/.kaggle/kaggle.json")
        print()
        print("Then run this script again.")
        print("─" * 55)
        print()
        print("Alternatively, manually download from:")
        print("  https://www.kaggle.com/datasets/microsoft/catsvsdogs")
        print("  → Extract to: kaggle_raw/ folder")
        print("  → Then run this script again (it will detect the folder)")
        return False

    # Try downloading
    download_path = "kaggle_raw"
    os.makedirs(download_path, exist_ok=True)

    ret = os.system(
        f"kaggle datasets download -d microsoft/catsvsdogs "
        f"-p {download_path} --unzip"
    )

    if ret != 0:
        print("⚠️  Kaggle download failed. Using synthetic only.")
        return False

    # Organize into dataset/train/real and dataset/val/real
    os.makedirs(os.path.join(output_dir, "train", "real"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "val",   "real"), exist_ok=True)

    # Collect all images from kaggle download
    all_images = []
    for root, _, files in os.walk(download_path):
        for f in files:
            if f.lower().endswith(('.jpg', '.jpeg', '.png')):
                all_images.append(os.path.join(root, f))

    random.shuffle(all_images)
    split = int(len(all_images) * 0.8)

    print(f"   Found {len(all_images)} real images. Organizing...")
    for idx, src in enumerate(all_images[:split]):
        ext = os.path.splitext(src)[1]
        shutil.copy(src, os.path.join(output_dir, "train", "real", f"real_{idx:05d}{ext}"))
    for idx, src in enumerate(all_images[split:]):
        ext = os.path.splitext(src)[1]
        shutil.copy(src, os.path.join(output_dir, "val", "real", f"real_{idx:05d}{ext}"))

    print(f"   ✅ Real: {split} train, {len(all_images)-split} val")
    return True


# ─────────────────────────────────────────────
# STEP 4: Train the Model
# ─────────────────────────────────────────────
def train_model(dataset_dir):
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader
    from torchvision import datasets, models, transforms

    print("\n[3/3] Training Model (Transfer Learning - ResNet18)...")
    print("─" * 55)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"   Device: {device}")

    # Transforms
    train_tf = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(15),
        transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])
    val_tf = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])

    train_ds = datasets.ImageFolder(os.path.join(dataset_dir, "train"), transform=train_tf)
    val_ds   = datasets.ImageFolder(os.path.join(dataset_dir, "val"),   transform=val_tf)

    class_names = train_ds.classes
    print(f"   Classes: {class_names}")
    print(f"   Train: {len(train_ds)} | Val: {len(val_ds)}")

    # Save class names
    os.makedirs("model", exist_ok=True)
    with open("model/class_names.txt", "w") as f:
        f.write("\n".join(class_names))

    train_dl = DataLoader(train_ds, batch_size=32, shuffle=True,  num_workers=0)
    val_dl   = DataLoader(val_ds,   batch_size=32, shuffle=False, num_workers=0)

    # Model
    model = models.resnet18(pretrained=True)
    for p in model.parameters():
        p.requires_grad = False
    model.fc = nn.Linear(model.fc.in_features, len(class_names))
    model = model.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.fc.parameters(), lr=0.001)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.1)

    best_acc = 0.0
    NUM_EPOCHS = 15

    for epoch in range(NUM_EPOCHS):
        # Train
        model.train()
        correct = total = 0
        for inputs, labels in train_dl:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            out  = model(inputs)
            loss = criterion(out, labels)
            loss.backward()
            optimizer.step()
            _, preds = torch.max(out, 1)
            correct += (preds == labels).sum().item()
            total   += labels.size(0)

        train_acc = correct / total

        # Val
        model.eval()
        vc = vt = 0
        with torch.no_grad():
            for inputs, labels in val_dl:
                inputs, labels = inputs.to(device), labels.to(device)
                out = model(inputs)
                _, preds = torch.max(out, 1)
                vc += (preds == labels).sum().item()
                vt += labels.size(0)
        val_acc = vc / vt

        print(f"   Epoch {epoch+1:02d}/{NUM_EPOCHS} | Train: {train_acc:.3f} | Val: {val_acc:.3f}", end="")

        if val_acc > best_acc:
            best_acc = val_acc
            torch.save({
                "model_state_dict": model.state_dict(),
                "class_names":      class_names,
                "num_classes":      len(class_names),
            }, "model/image_classifier.pth")
            print(" ✅ Saved!", end="")
        print()
        scheduler.step()

    print(f"\n🎉 Training Done! Best Val Accuracy: {best_acc:.4f}")
    print(f"   Model → model/image_classifier.pth")
    print(f"   Classes → {class_names}")
    print()
    print("Now run:")
    print("  python manage.py migrate")
    print("  python manage.py runserver")
    print("  → Open http://127.0.0.1:8000/")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
if __name__ == "__main__":
    DATASET_DIR = "dataset"

    print("\nWhat classes do you want?")
    print("  1. synthetic vs real  (Kakuda + Kaggle animals combined)")
    print("  2. cat vs dog         (Kaggle only, real images)")
    print("  3. synthetic only     (No internet needed — good for testing)")
    choice = input("\nEnter (1/2/3): ").strip()

    if choice == "3":
        # Synthetic only
        generate_synthetic(DATASET_DIR, num_images=400)
        # Also add a second class: "texture"
        from PIL import Image, ImageDraw
        import math
        os.makedirs(os.path.join(DATASET_DIR, "train", "texture"), exist_ok=True)
        os.makedirs(os.path.join(DATASET_DIR, "val",   "texture"), exist_ok=True)
        print("   Generating texture class...")
        for i in range(320):
            img = Image.new("RGB", (224, 224))
            draw = ImageDraw.Draw(img)
            for y in range(0, 224, 8):
                c = random.randint(100, 200)
                draw.rectangle([0, y, 224, y+4], fill=(c, c//2, 255-c))
            split_folder = "train" if i < 256 else "val"
            img.save(os.path.join(DATASET_DIR, split_folder, "texture", f"tex_{i:04d}.jpg"))
        print("   ✅ texture class ready")
        train_model(DATASET_DIR)

    elif choice == "2":
        # Cat vs Dog only
        success = download_real_dataset(DATASET_DIR)
        if not success:
            print("\n⚠️  Download failed. Generating synthetic as fallback...")
            generate_synthetic(DATASET_DIR, num_images=400)
        train_model(DATASET_DIR)

    else:
        # Synthetic + Real combined (DEFAULT)
        generate_synthetic(DATASET_DIR, num_images=500)
        success = download_real_dataset(DATASET_DIR)
        if not success:
            print("\n⚠️  Kaggle download skipped. Training with synthetic only.")
            # Add extra class
            from PIL import Image, ImageDraw
            os.makedirs(os.path.join(DATASET_DIR, "train", "real"), exist_ok=True)
            os.makedirs(os.path.join(DATASET_DIR, "val",   "real"), exist_ok=True)
            for i in range(400):
                img = Image.new("RGB", (224, 224))
                draw = ImageDraw.Draw(img)
                for _ in range(1000):
                    x, y = random.randint(0, 223), random.randint(0, 223)
                    c = (random.randint(50, 200), random.randint(100, 255), random.randint(50, 150))
                    draw.point((x, y), fill=c)
                for _ in range(5):
                    x1, y1 = random.randint(0, 150), random.randint(0, 150)
                    draw.ellipse([x1, y1, x1+50, y1+50],
                                 fill=(random.randint(100,255), random.randint(50,150), 50))
                folder = "train" if i < 320 else "val"
                img.save(os.path.join(DATASET_DIR, folder, "real", f"real_{i:04d}.jpg"))
            print("   ✅ Fallback real-style images generated")
        train_model(DATASET_DIR)
