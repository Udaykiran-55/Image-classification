"""
train_model.py - Train Image Classification Model using PyTorch
Dataset: Synthetic (Kakuda) + Real (Kavali from Kaggle)
Classes: Automatically detected from dataset folder structure

HOW TO USE:
1. Organize your dataset like this:
   dataset/
       train/
           class1/   (e.g., cat/)
               img1.jpg
               img2.jpg
           class2/   (e.g., dog/)
               img1.jpg
       val/
           class1/
           class2/

2. Run: python train_model.py
3. Model will be saved to: model/image_classifier.pth
4. Class names saved to: model/class_names.txt
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, models, transforms
import os
import json

# ===================== CONFIG =====================
DATASET_DIR = 'dataset'
MODEL_DIR = 'model'
MODEL_PATH = os.path.join(MODEL_DIR, 'image_classifier.pth')
CLASS_FILE = os.path.join(MODEL_DIR, 'class_names.txt')

NUM_EPOCHS = 15
BATCH_SIZE = 32
LEARNING_RATE = 0.001
IMAGE_SIZE = 224
# ==================================================

os.makedirs(MODEL_DIR, exist_ok=True)

# Data transforms
train_transforms = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(15),
    transforms.ColorJitter(brightness=0.2, contrast=0.2),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])

val_transforms = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])


def train_model():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # Load datasets
    train_dir = os.path.join(DATASET_DIR, 'train')
    val_dir = os.path.join(DATASET_DIR, 'val')

    if not os.path.exists(train_dir):
        print(f"ERROR: Dataset not found at '{train_dir}'")
        print("Please organize your dataset as described at the top of this file.")
        return

    train_dataset = datasets.ImageFolder(train_dir, transform=train_transforms)
    val_dataset = datasets.ImageFolder(val_dir, transform=val_transforms)

    class_names = train_dataset.classes
    num_classes = len(class_names)

    print(f"Classes found: {class_names}")
    print(f"Training samples: {len(train_dataset)}")
    print(f"Validation samples: {len(val_dataset)}")

    # Save class names
    with open(CLASS_FILE, 'w') as f:
        for name in class_names:
            f.write(name + '\n')
    print(f"Class names saved to {CLASS_FILE}")

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=2)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=2)

    # Use pretrained ResNet18 (transfer learning)
    model = models.resnet18(pretrained=True)
    # Freeze all layers except final
    for param in model.parameters():
        param.requires_grad = False
    # Replace final layer for our number of classes
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    model = model.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.fc.parameters(), lr=LEARNING_RATE)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.1)

    best_acc = 0.0

    for epoch in range(NUM_EPOCHS):
        print(f'\nEpoch {epoch+1}/{NUM_EPOCHS}')
        print('-' * 40)

        # Training phase
        model.train()
        running_loss = 0.0
        running_corrects = 0

        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            _, preds = torch.max(outputs, 1)
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)

        epoch_loss = running_loss / len(train_dataset)
        epoch_acc = running_corrects.double() / len(train_dataset)
        print(f'Train Loss: {epoch_loss:.4f}  Acc: {epoch_acc:.4f}')

        # Validation phase
        model.eval()
        val_corrects = 0
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, preds = torch.max(outputs, 1)
                val_corrects += torch.sum(preds == labels.data)

        val_acc = val_corrects.double() / len(val_dataset)
        print(f'Val Acc: {val_acc:.4f}')

        if val_acc > best_acc:
            best_acc = val_acc
            torch.save({
                'model_state_dict': model.state_dict(),
                'class_names': class_names,
                'num_classes': num_classes,
            }, MODEL_PATH)
            print(f'  ✅ Best model saved! (Val Acc: {best_acc:.4f})')

        scheduler.step()

    print(f'\n✅ Training complete! Best Val Accuracy: {best_acc:.4f}')
    print(f'Model saved to: {MODEL_PATH}')


if __name__ == '__main__':
    train_model()
