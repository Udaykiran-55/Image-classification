"""
predictor.py
=============
General Purpose Image Classifier using ImageNet pretrained ResNet50.
NO training needed. NO dataset needed.
Works for ANY image - animals, vehicles, food, people, nature, objects etc.
1000 categories supported out of the box!
"""

import torch
import torch.nn.functional as F
from torchvision import models, transforms
from PIL import Image
import urllib.request
import json
import os

LABELS_URL  = "https://raw.githubusercontent.com/anishathalye/imagenet-simple-labels/master/imagenet-simple-labels.json"
LABELS_FILE = os.path.join(os.path.dirname(__file__), '..', 'model', 'imagenet_labels.json')

preprocess = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std =[0.229, 0.224, 0.225]
    )
])

_model  = None
_labels = None


def get_labels():
    global _labels
    if _labels is not None:
        return _labels

    os.makedirs(os.path.dirname(LABELS_FILE), exist_ok=True)

    if not os.path.exists(LABELS_FILE):
        print("Downloading ImageNet labels...")
        try:
            urllib.request.urlretrieve(LABELS_URL, LABELS_FILE)
        except Exception:
            _labels = [f"class {i}" for i in range(1000)]
            return _labels

    with open(LABELS_FILE, "r") as f:
        _labels = json.load(f)
    return _labels


def load_model():
    global _model
    if _model is not None:
        return _model

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = models.resnet50(pretrained=True)
    model.eval()
    model = model.to(device)
    _model = model
    return _model


def predict_image(image_path):
    """
    Classify ANY image using ImageNet pretrained ResNet50.
    Returns top prediction + top-10 predictions with confidence %.
    """
    model  = load_model()
    labels = get_labels()
    device = next(model.parameters()).device

    img    = Image.open(image_path).convert("RGB")
    tensor = preprocess(img).unsqueeze(0).to(device)

    with torch.no_grad():
        outputs = model(tensor)
        probs   = F.softmax(outputs, dim=1)[0]

    vals, idxs = torch.topk(probs, k=10)
    vals  = vals.cpu().numpy()
    idxs  = idxs.cpu().numpy()

    def clean(label):
        return label.replace("_", " ").replace(",", " /").strip().title()

    top_class      = clean(labels[idxs[0]])
    top_confidence = round(float(vals[0]) * 100, 2)

    all_predictions = [
        {
            "class":      clean(labels[idx]),
            "confidence": round(float(conf) * 100, 2)
        }
        for conf, idx in zip(vals, idxs)
    ]

    return {
        "predicted_class": top_class,
        "confidence":      top_confidence,
        "all_predictions": all_predictions
    }
