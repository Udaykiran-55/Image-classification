from django.contrib import admin
from .models import ImagePrediction

@admin.register(ImagePrediction)
class ImagePredictionAdmin(admin.ModelAdmin):
    list_display = ['predicted_class', 'confidence', 'uploaded_at']
    list_filter = ['predicted_class']
    ordering = ['-uploaded_at']
