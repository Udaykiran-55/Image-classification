from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from .predictor import predict_image
from .models import ImagePrediction


def index(request):
    result     = None
    error      = None
    image_url  = None

    if request.method == 'POST' and request.FILES.get('image'):
        img_file = request.FILES['image']

        allowed = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp', 'image/bmp', 'image/gif']
        if img_file.content_type not in allowed:
            error = "Invalid file type. Please upload JPG, PNG, WEBP, or BMP images."
        else:
            fs       = FileSystemStorage()
            filename = fs.save(f"uploads/{img_file.name}", img_file)
            saved_path = fs.path(filename)
            image_url  = fs.url(filename)

            try:
                prediction = predict_image(saved_path)

                ImagePrediction.objects.create(
                    image=filename,
                    predicted_class=prediction['predicted_class'],
                    confidence=prediction['confidence']
                )
                result = prediction

            except Exception as e:
                error = f"Error: {str(e)}"

    recent = ImagePrediction.objects.order_by('-uploaded_at')[:6]

    return render(request, 'classifier/index.html', {
        'result':    result,
        'error':     error,
        'image_url': image_url,
        'recent':    recent,
    })


def history(request):
    predictions = ImagePrediction.objects.order_by('-uploaded_at')
    return render(request, 'classifier/history.html', {'predictions': predictions})
