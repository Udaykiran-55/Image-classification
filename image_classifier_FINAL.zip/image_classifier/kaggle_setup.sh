# Kaggle Dataset Download Guide
# ================================
# Run this script to setup Kaggle API and download dataset

# STEP 1: Install kaggle package
pip install kaggle

# STEP 2: Get your Kaggle API Key
# 1. Go to: https://www.kaggle.com/settings/account
# 2. Scroll to "API" section
# 3. Click "Create New Token" → downloads kaggle.json

# STEP 3: Place kaggle.json in correct location
# Windows:  C:\Users\YourName\.kaggle\kaggle.json
# Linux/Mac: ~/.kaggle/kaggle.json

# STEP 4: Run dataset_setup.py
python dataset_setup.py
# → Choose option 1 for Kaggle download
# → Choose option 2 for Synthetic (no internet needed)

# ─────────────────────────────────────────────────
# POPULAR DATASETS ON KAGGLE
# ─────────────────────────────────────────────────

# Animals (Cat vs Dog):
kaggle datasets download -d microsoft/catsvsdogs

# Flowers (5 classes):
kaggle datasets download -d alxmamaev/flowers-recognition

# Brain Tumor (Medical):
kaggle datasets download -d navoneel/brain-mri-images-for-brain-tumor-detection

# Plant Disease:
kaggle datasets download -d emmarex/plantdisease

# ─────────────────────────────────────────────────
# AFTER DOWNLOADING
# ─────────────────────────────────────────────────
# Run: python dataset_setup.py → Option 3 (Use own images)
# Then: python train_model.py
# Then: python manage.py runserver
